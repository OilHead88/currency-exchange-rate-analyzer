import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class vyCLASS {
    public static void main(String[] args) throws IOException {
//        урок 2 задание 9

//        String str = "";
//        Scanner scanner = new Scanner(System.in);
//
//
//
//
//           while (!str.contains("    ")) {
//                System.out.print("Please enter string: ");
//                str = scanner.next();
//                System.out.println(str.charAt(0));
//            }
//
//                System.out.println("stop");
//


//        урок 2 задание 11


        String page = downloadWebPage("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY");
        int urlBegin = page.lastIndexOf("url");
        int urlEnd = page.lastIndexOf("}");
        String url = page.substring(urlBegin + 6, urlEnd - 1);
        try (InputStream in = new URL(url).openStream()) {
            Files.copy(in, Paths.get("new.jpg"));
        }
        System.out.println("Picture saved!");

//        int explanationBegin = page.lastIndexOf("explanation");
//        int explanationEnd = page.lastIndexOf("hdurl");
//        String explanation = page.substring(explanationBegin + 13, explanationEnd - 3);
//        System.out.println(explanation);
//
//        try (InputStream in = new URL(url).openStream()){
//            Files.copy(in, Paths.get("image.jpg"));
    }


    private static String downloadWebPage(String url) throws IOException {
        StringBuilder result = new StringBuilder();
        String line;

        URLConnection urlConnection = new URL(url).openConnection();
        urlConnection.addRequestProperty("User-Agent", "Mozilla");
        urlConnection.setReadTimeout(5000);
        urlConnection.setConnectTimeout(5000);

        try (InputStream is = urlConnection.getInputStream(); BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            while ((line = br.readLine()) != null) {
                result.append(line);
            }
        }
        return result.toString();
    }
}
//}
//
//
//
//
//
//
//
//
//
