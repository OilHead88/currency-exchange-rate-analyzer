import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;

public class dfdf {
    public static void main(String[] args) {

    }

    public class NASAPhotoCollector {

        private static final String NASA_URL = "https://api.nasa.gov/planetary/apod";
        private static final String NASA_KEY = "YOUR_NASA_API_KEY_HERE";
        private static final String PHOTO_FOLDER = "./nasa_photos/";


        public void main(String[] args) {

            // Create NASA photos folder if it doesn't exist
            File folder = new File(PHOTO_FOLDER);
            if (!folder.exists()) {
                folder.mkdir();
            }

            // Get current date and format it as yyyy-MM-dd
            Calendar calendar = Calendar.getInstance();
            Date endDate = calendar.getTime();
            calendar.add(Calendar.MONTH, -1);
            Date startDate = calendar.getTime();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

            // Collect photo URLs for the given date range
            List<String> photoUrls = new ArrayList<>();
            calendar.setTime(startDate);
            while (calendar.getTime().before(endDate)) {
                String date = formatter.format(calendar.getTime());
                String url = NASA_URL + "?api_key=" + NASA_KEY + "&date=" + date;
                try {
                    URL nasaUrl = new URL(url);
                    BufferedReader reader = new BufferedReader(new InputStreamReader(nasaUrl.openStream()));
                    String line;
                    StringBuilder jsonResult = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        jsonResult.append(line);
                    }
                    reader.close();
                    Map<String, String> photoInfo = parseJson(jsonResult.toString());
                    String photoUrl = photoInfo.get("hdurl");
                    if (photoUrl == null || photoUrl.isEmpty()) {
                        photoUrl = photoInfo.get("url");
                    }
                    photoUrls.add(photoUrl);
                    System.out.println("Collected photo for " + date);
                } catch (Exception e) {
                    System.err.println("Error while collecting photo for " + date + ": " + e.getMessage());
                }
                calendar.add(Calendar.DATE, 1);
            }

        }
    }

    private Map<String, String> parseJson(String string) {
        return null;
    }


}